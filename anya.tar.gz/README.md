# 🩷 Anya — IRC Bot Modulaire (Undernet / Libera / ZNC)

> Petite bot russe numérique, sarcastique, cute, chouette, mood‑based, avec DB, météo, quotes, roast, fêtes, canards, seen, multi‑channels et modules avancés.

---

## 🎵 Playlist Vandresse (Geocities Style)

[YouTube Playlist — Vandresse](https://www.youtube.com/playlist?list=PLIk2NJhFJy5U)

> À écouter pendant que tu codes Anya.  
> Ambiance rétro, cyber‑occult, Ghost Network vibes.

---

## 🚀 Fonctionnalités

- Multi‑serveurs IRC (Undernet, Libera)
- Multi‑channels (#montreal, #kodi)
- Support ZNC (PASS auto)
- Météo (OpenWeatherMap)
- Seen (SQLite)
- Quotes + random
- Insultes random
- Fêtes du jour
- Canards random
- Personnalité russe cute
- Sarcasme
- Humeur aléatoire
- Heure intelligente
- Roast des autres bots
- Architecture modulaire PRO

---

## 🧩 Structure

anya/
├── anya.py
├── anya_server.py
├── anya_db.py
├── anya_fun.py
├── anya_weather.py
├── anya_personality.py
├── anya_mood.py
├── anya_time.py
├── anya_bots.py
└── requirements.txt


---

## ⚙️ Installation (WSL)

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 anya.py
