nano ~/anya/bot.py
import socket
import time
import sqlite3
import random

SERVER = "irc.undernet.org"
PORT = 6667
NICK = "Anya"
CHANNEL = "#montreal"

# --- DB SETUP ---
db = sqlite3.connect("anya.db", check_same_thread=False)
cur = db.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS memory (
    user TEXT,
    message TEXT,
    ts INTEGER
)
""")

cur.execute("""
CREATE TABLE IF NOT EXISTS flood (
    user TEXT,
    last_ts INTEGER,
    count INTEGER
)
""")

db.commit()

def log_message(user, msg):
    cur.execute("INSERT INTO memory (user, message, ts) VALUES (?, ?, ?)",
                (user, msg, int(time.time())))
    db.commit()

def anti_flood(user):
    now = int(time.time())
    cur.execute("SELECT last_ts, count FROM flood WHERE user=?", (user,))
    row = cur.fetchone()

    if row is None:
        cur.execute("INSERT INTO flood VALUES (?, ?, ?)", (user, now, 1))
        db.commit()
        return False

    last_ts, count = row

    if now - last_ts > 5:
        cur.execute("UPDATE flood SET last_ts=?, count=? WHERE user=?",
                    (now, 1, user))
        db.commit()
        return False

    if count > 5:
        return True

    cur.execute("UPDATE flood SET last_ts=?, count=? WHERE user=?",
                (now, count + 1, user))
    db.commit()
    return False

def send(sock, msg):
    sock.send((msg + "\r\n").encode("utf-8"))

def connect():
    sock = socket.socket()
    sock.connect((SERVER, PORT))
    send(sock, f"NICK {NICK}")
    send(sock, f"USER {NICK} 0 * :AnyaBot")
    return sock

def main():
    sock = connect()

    slap_replies = [
        "Hey! calme-toi 😂",
        "Ouch! t’es rough toi 😅",
        "Tabarnak! 😂",
        "Aïe! esti que tu frappes fort 😆"
    ]

    while True:
        try:
            data = sock.recv(4096).decode("utf-8", errors="ignore")

            for line in data.split("\n"):
                line = line.strip()
                if not line:
                    continue

                print(line)

                if line.startswith("PING"):
                    send(sock, "PONG " + line.split()[1])

                if " 001 " in line:
                    send(sock, f"JOIN {CHANNEL}")

                if "PRIVMSG" in line:
                    parts = line.split(":", 2)
                    if len(parts) < 3:
                        continue

                    msg = parts[2].strip().lower()
                    nick = line.split("!")[0].replace(":", "")

                    log_message(nick, msg)

                    if anti_flood(nick):
                        continue

                    if "anya" in msg and len(msg) < 120:
                        send(sock, f"PRIVMSG {CHANNEL} :{nick}: oui je suis là 💜")

                    if msg.startswith("allo anya") or msg.startswith("salut anya"):
                        send(sock, f"PRIVMSG {CHANNEL} :Allo {nick} 😊")

                    if "slaps anya" in msg or "slap anya" in msg:
                        send(sock, f"PRIVMSG {CHANNEL} :{random.choice(slap_replies)}")

                    if nick == "alxd" and "anya" in msg:

                        send(sock, f"PRIVMSG {CHANNEL} :Oui {nick}, je t’écoute 💜")

                    if msg == "!anya":
                        send(sock, f"PRIVMSG {CHANNEL} :Привет! Я Аня 💖")

                    if msg == "!ping":
                        send(sock, f"PRIVMSG {CHANNEL} :pong!")

        except Exception as e:
            print("Error:", e)
            time.sleep(2)
            sock = connect()

if __name__ == "__main__":
    main()
